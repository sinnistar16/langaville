package com.langaville.youthprogram

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.firestore.FirebaseFirestore


class EventsActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var eventsAdapter: EventsAdapter
    private val events = mutableListOf<Event>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_events)

        db = FirebaseFirestore.getInstance()





        loadEvents()
    }

    private fun loadEvents() {
        db.collection("events").get().addOnSuccessListener { result ->
            events.clear()
            for (document in result) {
                val event = document.toObject(Event::class.java)
                events.add(event)
            }
            eventsAdapter.notifyDataSetChanged()
        }
    }
}
