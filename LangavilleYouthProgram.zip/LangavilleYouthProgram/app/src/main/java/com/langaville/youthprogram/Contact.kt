package com.langaville.youthprogram

data class Contact(
    val id: String = "",
    val name: String = "",
    val profileImageUrl: String = ""
)
