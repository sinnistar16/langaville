package com.langaville.youthprogram
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ProfileActivity : AppCompatActivity() {

    companion object {
        private const val PICK_IMAGE_REQUEST = 1
    }

    private lateinit var imgProfilePicture: ImageView
    private lateinit var etAboutMe: EditText
    private lateinit var btnEditAboutMe: TextView
    private var isEditingAboutMe = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)


        val btnNotifications: ImageView = findViewById(R.id.btnNotifications)
        val btnUploadResource: Button = findViewById(R.id.btnUploadResource)
        val personalInfoBtn: TextView = findViewById(R.id.personalinfobtn)

        imgProfilePicture = findViewById(R.id.imgProfilePicture)
        etAboutMe = findViewById(R.id.etAboutMe)
        btnEditAboutMe = findViewById(R.id.btnEditAboutMe)




        // Notifications button click listener
        btnNotifications.setOnClickListener {
            Toast.makeText(this, "Notifications clicked", Toast.LENGTH_SHORT).show()
            // Handle notifications click
        }

        // Upload button click listener
        btnUploadResource.setOnClickListener {
            openFileChooser()
        }

        // User Info button click listener
        personalInfoBtn.setOnClickListener {
            Toast.makeText(this, "User Info clicked", Toast.LENGTH_SHORT).show()
            // Handle user info click
        }

        // Profile picture click listener
        imgProfilePicture.setOnClickListener {
            openFileChooser()
        }

        // Edit "About Me" button click listener
        btnEditAboutMe.setOnClickListener {
            if (isEditingAboutMe) {
                etAboutMe.isEnabled = false
                btnEditAboutMe.text = "Edit"
                // Save the new "About Me" text (e.g., to a server or local storage)
            } else {
                etAboutMe.isEnabled = true
                btnEditAboutMe.text = "Save"
            }
            isEditingAboutMe = !isEditingAboutMe
        }
    }

    private fun openFileChooser() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            val selectedImageUri: Uri? = data.data
            imgProfilePicture.setImageURI(selectedImageUri)
            // Handle the selected image (e.g., upload to server or save locally)
            Toast.makeText(this, "Resource uploaded: $selectedImageUri", Toast.LENGTH_SHORT).show()
        }
    }
}
