package com.langaville.youthprogram.com.langaville.youthprogram

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.regex.Pattern
import androidx.core.content.ContextCompat
import com.langaville.youthprogram.LoginActivity
import com.langaville.youthprogram.R

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var tvError: TextView
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val etName: EditText = findViewById(R.id.etName)
        val etSurname: EditText = findViewById(R.id.etSurname)
        val etUsername: EditText = findViewById(R.id.etUsername)
        val etEmail: EditText = findViewById(R.id.etEmail)
        val etPassword: EditText = findViewById(R.id.etPassword)
        val btnRegister: Button = findViewById(R.id.btnRegister)
        tvError = findViewById(R.id.tvError)
        btnLogin = findViewById(R.id.btnLogin)

        btnRegister.setOnClickListener {
            val name = etName.text.toString().trim()
            val surname = etSurname.text.toString().trim()
            val username = etUsername.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (validateInput(name, surname, username, email, password)) {
                checkUsernameAndRegister(name, surname, username, email, password)
            }
        }

        btnLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish() // Optional: Finish the current activity to prevent users from navigating back to it
        }
    }

    private fun clearError() {
        tvError.text = ""
        tvError.visibility = TextView.GONE
    }

    private fun showErrorMessage(message: String) {
        tvError.text = message
        tvError.setTextColor(ContextCompat.getColor(this, R.color.error_color))
        tvError.visibility = TextView.VISIBLE
    }

    private fun showSuccessMessage(message: String) {
        tvError.text = message
        tvError.setTextColor(ContextCompat.getColor(this, R.color.success_color))
        tvError.visibility = TextView.VISIBLE
    }

    private fun validateInput(
        name: String,
        surname: String,
        username: String,
        email: String,
        password: String
    ): Boolean {
        return when {
            name.isEmpty() -> {
                showErrorMessage("Name is required.")
                false
            }
            surname.isEmpty() -> {
                showErrorMessage("Surname is required.")
                false
            }
            username.isEmpty() -> {
                showErrorMessage("Username is required.")
                false
            }
            email.isEmpty() -> {
                showErrorMessage("Email is required.")
                false
            }
            !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                showErrorMessage("Please enter a valid email address.")
                false
            }
            password.isEmpty() -> {
                showErrorMessage("Password is required.")
                false
            }
            !validatePassword(password) -> {
                // Password validation failed; the error is already shown in validatePassword function
                false
            }
            else -> {
                clearError()
                true
            }
        }
    }

    private fun validatePassword(password: String): Boolean {
        val passwordPattern = Pattern.compile(
            "^" +
                    "(?=.*[0-9])" +        // at least 1 digit
                    "(?=.*[a-z])" +        // at least 1 lower case letter
                    "(?=.*[A-Z])" +        // at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +     // any letter
                    "(?=.*[@#$%^&+=!])" +  // at least 1 special character
                    "(?=\\S+$)" +          // no white spaces
                    ".{8,}" +              // at least 8 characters
                    "$"
        )

        return if (!passwordPattern.matcher(password).matches()) {
            showErrorMessage("Password must contain at least 8 characters, including a digit, a lower case letter, an upper case letter, and a special character.")
            false
        } else {
            clearError()
            true
        }
    }

    private fun checkUsernameAndRegister(
        name: String,
        surname: String,
        username: String,
        email: String,
        password: String
    ) {
        db.collection("users").whereEqualTo("username", username).get()
            .addOnSuccessListener { documents ->
                if (documents.isEmpty) {
                    registerUser(name, surname, username, email, password)
                } else {
                    showErrorMessage("Username is already taken.")
                }
            }
            .addOnFailureListener { exception ->
                showErrorMessage("Failed to check username: ${exception.localizedMessage}")
            }
    }

    private fun navigateToLoginScreen() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun registerUser(
        name: String,
        surname: String,
        username: String,
        email: String,
        password: String
    ) {
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    val userId = user?.uid ?: return@addOnCompleteListener
                    val userMap = hashMapOf(
                        "name" to name,
                        "surname" to surname,
                        "username" to username,
                        "email" to email
                    )

                    db.collection("users").document(userId).set(userMap)
                        .addOnSuccessListener {
                            clearError() // Clear error message
                            showSuccessMessage("Registration successful")
                            navigateToLoginScreen()
                        }
                        .addOnFailureListener { exception ->
                            showErrorMessage("Failed to save user data: ${exception.localizedMessage}")
                        }
                } else {
                    task.exception?.let {
                        if (it.localizedMessage?.contains("email address is already in use") == true) {
                            showErrorMessage("Email address is already in use. Please use a different email.")
                        } else {
                            showErrorMessage(it.localizedMessage ?: "Registration failed.")
                        }
                    }
                }
            }
    }
}
