package com.langaville.youthprogram

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore




class MessagesActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var messagesAdapter: MessagesAdapter
    private val messages = mutableListOf<Message>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_messages)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        messagesAdapter = MessagesAdapter(messages)

        val recyclerViewMessages = null
        recyclerViewMessages.apply {
            var layoutManager = LinearLayoutManager(this@MessagesActivity)
            var adapter = messagesAdapter
        }

        val contactId = intent.getStringExtra("CONTACT_ID")
        if (contactId != null) {
            loadMessages(contactId)
        }



    }

    private fun loadMessages(contactId: String) {
        db.collection("chats").document(contactId)
            .collection("messages")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null) {
                    messages.clear()
                    for (document in snapshot.documents) {
                        val message = document.toObject(Message::class.java)
                        if (message != null) {
                            messages.add(message)
                        }
                    }
                    messagesAdapter.notifyDataSetChanged()
                }
            }
    }

    private fun sendMessage(contactId: String?, messageText: String) {
        if (contactId != null) {
            val message = Message(auth.currentUser?.uid ?: "", messageText, System.currentTimeMillis())
            db.collection("chats").document(contactId)
                .collection("messages").add(message)
        }
    }
}
