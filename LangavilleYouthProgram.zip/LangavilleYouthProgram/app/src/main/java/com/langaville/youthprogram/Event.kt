package com.langaville.youthprogram

data class Event(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val date: Long = 0,
    val location: String = ""
)
