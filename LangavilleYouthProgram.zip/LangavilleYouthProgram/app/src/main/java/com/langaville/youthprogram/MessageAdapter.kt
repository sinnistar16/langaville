package com.langaville.youthprogram

// MessageAdapter.kt
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView


class MessageAdapter(private val context: Context, private val messages: MutableList<Message>) : BaseAdapter() {
    override fun getCount(): Int = messages.size
    override fun getItem(position: Int): Any = messages[position]
    override fun getItemId(position: Int): Long = position.toLong()
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_message, parent, false)
        val message = getItem(position) as Message
        val messageTextView: TextView = view.findViewById(R.id.message_text)
        messageTextView.text = message.text
        return view
    }

    fun add(message: Message) {
        messages.add(message)
        notifyDataSetChanged()
    }
}
